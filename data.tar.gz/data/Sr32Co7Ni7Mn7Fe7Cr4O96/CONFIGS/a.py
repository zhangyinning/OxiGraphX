import os
y=[]
for i in range(1, 101):
    for x in range(1, 11):
        filename = 'DEFECT_'+str(i)+'_'+str(x)+'.vacancy_formation_energy'
        with open(filename, "r") as f:
            data = f.readlines()
        f.close()
        y.append(data)
   
file_name = 'DEFECT_ENERGY_EV'
with open(file_name, "w") as f:
    for i in range(1000):
        f.write(str(y[i]))
        f.write('\n')


import os
y=[]
for i in range(1, 101):
    for x in range(1, 11):
        filename = 'DEFECT_'+str(i)+'_'+str(x)+'.energy'
        with open(filename, "r") as f:
            data = f.readlines()
        f.close()
        y.append(data)
   
file_name = 'ENERGY_EV'
with open(file_name, "w") as f:
    for i in range(1000):
        f.write(str(y[i]))
        f.write('\n')